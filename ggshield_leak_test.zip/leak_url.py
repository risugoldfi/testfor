# Basic Auth URL
url = "https://user:password123@myserver.com/data"
