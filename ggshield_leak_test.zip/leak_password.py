# Hardcoded password
db_password = "superSecret123"
